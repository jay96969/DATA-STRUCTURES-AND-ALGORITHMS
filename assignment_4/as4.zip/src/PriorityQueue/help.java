package PriorityQueue;

import java.io.IOException;

public class help {
	
	 public static void main(String[] args) throws IOException {
		 MaxHeap<Student> m = new MaxHeap<>();
		 Student s1=new Student("ram1",40);
		 Student s2=new Student("ram2",240);
		 Student s3=new Student("ram3",40);
		 Student s4=new Student("ram4",240);
		 Student s5=new Student("ram5",40);
		 Student s6=new Student("ram6",940);
		 Student s7=new Student("ram7",40);
		 Student s8=new Student("ram8",240);
		 Student s9=new Student("ram9",940);
		 
		 m.insert(s1);
		 m.insert(s2);
		 m.insert(s3);
		 m.insert(s4);
		 m.insert(s5);
		 m.insert(s6);
		 m.insert(s7);
		 m.insert(s8);
		 m.insert(s9);
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 System.out.println(m.extractMax().toString());
		 

}
}