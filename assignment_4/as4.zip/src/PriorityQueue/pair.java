package PriorityQueue;


	 public class pair<T>
	    {  int x;
	       T  y;
	    public pair(T a,int b)
	    {
	    	this.x=b;
	    	this.y=a;
	    }
	    }

