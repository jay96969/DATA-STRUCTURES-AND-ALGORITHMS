package PriorityQueue;

import java.util.ArrayList;
import java.util.Iterator;

import ProjectManagement.Job;

public class MaxHeap<T extends Comparable>implements PriorityQueueInterface<T> {

	public pair<T>[] contents;
    public int numItems;
    public int gt=1;
    
   
    public MaxHeap() {
        contents = (pair<T>[])new pair[10000];      
        numItems = 0;
    }
    
    
    private void siftUp(int i) {
        pair<T> toSift = contents[i];
        
        int child = i;
        while (child > 0) {
            int parent = (child+1)/2;
            
            // Check if we're done.
            if (toSift.y.compareTo(contents[parent-1].y) <= 0 ) {
                break;
            }
            
            
            contents[child] = contents[parent-1];
            child = parent-1;
        }
        
        contents[child] = toSift;
    }
    @Override
    public void insert(T element) {
    	
        gt++;
        pair<T> ne=new pair<T>(element,gt);
        contents[numItems] = ne;
        
        siftUp(numItems);
        numItems++;
    }
    public pair<T> peek()
    {
    	return contents[0];
    }
    
    private void siftDown(int i) {
       pair<T> toSift = contents[i];
        
        
        int parent = i;
        int child = 2 * parent + 1;
        while (child < numItems) {
           
 
        	
        	
            if (child < numItems - 1  &&
                contents[child].y.compareTo(contents[child + 1].y) <= 0) {
                child = child + 1;
            }
            
            
            
            if (toSift.y.compareTo(contents[child].y) > 0) {
                break;
            }
            
          
            contents[parent] = contents[child];
            parent = child;
            child = 2 * parent + 1;
        }
        
        contents[parent] = toSift;
    }

    @Override
    public T extractMax() {
    	 if (numItems==0) return null;
     	T toRemove   = contents[0].y;
     	contents[0] = contents[numItems - 1];
     numItems--;
     siftDown(0);
     
     return toRemove;
    }
}