trie;


1  trie node;
     it has 127 character array,and it has a boolean isEnd which do check for end of node
     and a getvalue fucntion that return value of end node;
  
In trie class
   1. isEmpty=it check whether a node has empty array;
   2.  insert = it iterate through root node and when it find a null index in any node
                      it create a new node.at the end of word it turn the  isEnd true
                     and assign a value to that node.
    3. delete = it iterate through root node and every time it store the parent pointer
                       and a son index.
                        when we reach at the end we iterate word backward through the 
                         son and parent pointer and check whether count of subnodes 
                     are 0 or not OR its isEnd boolean is true or false.
                       turn the son index null accordingly.
  4.  prefix.=it itrate through prefix word  and return that last node;
   5 print level=it recursively reach at the required level node and add those char to a string
                        and i use bubble sort to sort the char in array.and return the array.
    6. print =it print all levels.
                         count of total level are store in depth integer.
    
     7.printtrie. it recursively  reach all end nodes after that node and return the value.  
     8. seach . it itrate through word and check wether there isEnd true or not.


2. Max heap
       pair class
                it made up with T and an int.
                  it works as node of heap.T store the value and and int store the insert time
          insert ;
                  insert element at last and call the sift up function
          shiftup; it shift up the last node till it find higher priority node or equal priority node
         delete=it remove the first element of array and put last at first.
                        call the siftdown function
            shiftdown=  it shift the first node down till it find the less priority node.

3.  redblacktree;
      rbnode  ;it has a arraylist to store  the values of same keys.
                     it has two pointer left n right
                     a boolean color; a int size;
                     
        rbtree
               1.insertnode; first it check if the node is null or not.
                                    it recursively reach at null node(simple bst method)
                                    Color of a NULL node is considered as BLACK.
                         

          Let x be the newly inserted node.assign its color red.
1) If x is root, change color of x as bla;ck   

3) if color of x’s parent is not black and x is not root.
        a) If x’s uncle is Red 
            recloring

b) If x’s uncle is BLACK, then there can be four configurations for x, x’s parent (p) and x’s grandparent (g) (This is similar to AVL Tree)
   a) Left Left Case=right rotation and swap color
.   b) Left Right Case =left rotation and apply case a
   c) Right Right Case=left rotate and swap color

   d) Right Left Case=left rotate and apply case c

