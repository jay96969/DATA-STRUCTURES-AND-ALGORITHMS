
public class Student implements Student_ {

	String fname;
	public String fname() {
		
		return fname;
	}

	String lname;
	public String lname() {
		
		
		return lname;
	}

	String hostel;
	public String hostel() {
		
		return hostel;
	}

	String department;
	public String department() {
		
		return department;
	}

	String cgpa;
	public String cgpa() {
		
		return cgpa;
	}

}
