public class HashEntry<K,T> 
{
    K key;
    T value;    
 
    HashEntry(K key,T value) 
    {
        this.key = key;
        this.value = value;        
    }
   /* public int equals(HashEntry<K,T> obj)
    {   
    	obj.key.
}*/
}
